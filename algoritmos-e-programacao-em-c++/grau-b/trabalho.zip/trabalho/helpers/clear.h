#include <stdlib.h>

void clear() {
	system("@cls||clear");
}
